#### Folder Structure
-view: Web Components
-controller: Connect the view components with the FPD API
-classes: The FancyProductDesigner classes which will interact with the controllers
-vendor: All third-party assets
-fabricjs: Relevant fabricjs prototypes & modules

